import { execFile } from "node:child_process";
import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { existsSync } from "node:fs";
import { createRequire } from "node:module";

const execFileAsync = promisify(execFile);
const MAX_INPUT_BYTES = 25 * 1024 * 1024;
const TIMEOUT_MS = 120_000;

const GENERATED_HEADER = "-- generated in discord.gg/g7WB4VqHZt\n";

async function prependGeneratedHeader(outputPath: string): Promise<Uint8Array> {
  const existing = await readFile(outputPath, "utf8");
  const content = existing.startsWith(GENERATED_HEADER)
    ? existing
    : `${GENERATED_HEADER}${existing}`;
  await writeFile(outputPath, content, "utf8");
  return new TextEncoder().encode(content);
}

export interface DeobfuscationResult {
  outputPath: string;
  outputName: string;
  outputBytes: number;
}

export type MoonsecOutputMode = "dev" | "dis";

export interface MoonsecResult {
  outputPath: string;
  outputName: string;
  outputBytes: number;
  mode: MoonsecOutputMode;
}

export interface Ib2Result {
  outputPath: string;
  outputName: string;
  outputBytes: number;
}

export interface IronveilResult {
  outputPath: string;
  outputName: string;
  outputBytes: number;
}

export interface MoonveilResult {
  outputPath: string;
  outputName: string;
  outputBytes: number;
}

export interface LuauVmpResult {
  outputPath: string;
  outputName: string;
  outputBytes: number;
}

export interface BeautifyResult {
  outputPath: string;
  outputName: string;
  outputBytes: number;
}

function getEnginePath(): string {
  return join(
    dirname(fileURLToPath(import.meta.url)),
    "deobfuscator",
    "deobfuscator.py",
  );
}

function getPrometheusEnginePath(): string {
  return join(
    dirname(fileURLToPath(import.meta.url)),
    "prometheus",
    "runner.js",
  );
}

function getBeautifyEnginePath(): string {
  return join(
    dirname(fileURLToPath(import.meta.url)),
    "beautify",
    "beautify_cli.js",
  );
}

function getIb2EnginePath(): string {
  return join(
    dirname(fileURLToPath(import.meta.url)),
    "ib2",
    "LuaAnalysis.Ironbrew2.dll",
  );
}

function getSafeProcessEnv(): NodeJS.ProcessEnv {
  const libraryDirectories = new Set<string>();

  for (const variable of [
    "LD_LIBRARY_PATH",
    "REPLIT_LD_LIBRARY_PATH",
    "PYTHON_LD_LIBRARY_PATH",
  ]) {
    for (const directory of (process.env[variable] ?? "").split(":")) {
      if (directory) libraryDirectories.add(directory);
    }
  }

  for (const pathEntry of (process.env["PATH"] ?? "").split(":")) {
    if (!pathEntry.includes("/nix/store/")) continue;
    const libraryDirectory = join(pathEntry, "..", "lib");
    if (existsSync(libraryDirectory)) libraryDirectories.add(libraryDirectory);
  }

  return {
    PATH: process.env["PATH"] ?? "",
    HOME: process.env["HOME"] ?? "/tmp",
    LANG: "C.UTF-8",
    LC_ALL: "C.UTF-8",
    TMPDIR: process.env["TMPDIR"] ?? "/tmp",
    LUA51_EXECUTABLE: process.env["LUA51_EXECUTABLE"] ?? getBundledLua51Path(),
    LD_LIBRARY_PATH: [...libraryDirectories].join(":"),
    REPLIT_LD_LIBRARY_PATH: process.env["REPLIT_LD_LIBRARY_PATH"] ?? "",
  };
}

function getMoonsecDirectory(): string {
  return join(dirname(fileURLToPath(import.meta.url)), "moonsec");
}

function getBundledLua51Path(): string {
  return join(getMoonsecDirectory(), "decompiler", "lua5.1");
}

function getBundledDecompilerScript(): string {
  return join(getMoonsecDirectory(), "decompiler", "decom.lua");
}

function getMoonveilDirectory(): string {
  return join(dirname(fileURLToPath(import.meta.url)), "engines", "moonveil");
}

function getLuauVmpDirectory(): string {
  return join(dirname(fileURLToPath(import.meta.url)), "engines", "luau-vmp");
}

function getPythonPath(extraPath?: string): string {
  const paths = [
    extraPath,
    process.env["REPLIT_PYTHONPATH"],
    process.env["PYTHONPATH"],
  ].filter((value): value is string => Boolean(value));
  return [...new Set(paths.join(":").split(":").filter(Boolean))].join(":");
}

function getPythonEnv(extraPath?: string): NodeJS.ProcessEnv {
  return {
    ...getSafeProcessEnv(),
    PYTHONPATH: getPythonPath(extraPath),
  };
}

function engineError(
  error: unknown,
  fallback: string,
  timeoutMessage: string,
): Error {
  const details = error as {
    killed?: boolean;
    stderr?: string;
    stdout?: string;
  };
  if (details.killed) return new Error(timeoutMessage);

  const output = `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
  const usefulLine = output
    .split("\n")
    .map((line) => line.trim())
    .find(
      (line) =>
        line.startsWith("[!]") ||
        line.startsWith("Error") ||
        line.startsWith("Invalid") ||
        line.startsWith("Unhandled") ||
        line.includes("failed"),
    );
  return new Error(usefulLine ?? fallback);
}

export async function deobfuscateLua(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<DeobfuscationResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "wearedevs-deobf-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
  const outputPath = `${inputPath}.deobf.lua`;

  try {
    await writeFile(inputPath, fileBytes);

    try {
      await execFileAsync(
        process.env["NODE_EXECUTABLE"] ?? process.execPath,
        [getPrometheusEnginePath(), inputPath, outputPath],
        {
          cwd: workingDir,
          env: getSafeProcessEnv(),
          timeout: TIMEOUT_MS,
          maxBuffer: 8 * 1024 * 1024,
        },
      );
    } catch (error) {
      const details = error as {
        killed?: boolean;
        stderr?: string;
        stdout?: string;
      };
      if (details.killed) {
        throw new Error("The Prometheus engine timed out after 120 seconds.");
      }

      const output =
        `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
      const usefulLine = output
        .split("\n")
        .map((line) => line.trim())
        .find(
          (line) =>
            line.startsWith("Error") ||
            line.startsWith("Invalid") ||
            line.startsWith("Unhandled"),
        );
      throw new Error(
        usefulLine ?? "The Prometheus engine could not process this Lua file.",
      );
    }

    if (!(await readFile(outputPath)).byteLength) {
      throw new Error("The deobfuscation engine returned an empty file.");
    }

    try {
      await execFileAsync(
        process.env["PYTHON_EXECUTABLE"] ?? "python3",
        [join(dirname(getEnginePath()), "clean_output.py"), outputPath],
        {
          cwd: dirname(getEnginePath()),
          env: getSafeProcessEnv(),
          timeout: 10_000,
          maxBuffer: 1 * 1024 * 1024,
        },
      );
    } catch {
      // Output cleanup is best-effort; the engine output itself remains available.
    }

    const outputBytes = await prependGeneratedHeader(outputPath);
    return {
      outputPath,
      outputName: `${inputName.replace(/\.lua$/i, "")}.deobf.lua`,
      outputBytes: outputBytes.byteLength,
    };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function deobfuscateBeautify(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<BeautifyResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "beautify-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
  const outputPath = `${inputPath}.beautify.lua`;

  try {
    await writeFile(inputPath, fileBytes);

    try {
      await execFileAsync(
        process.env["NODE_EXECUTABLE"] ?? process.execPath,
        [getBeautifyEnginePath(), inputPath, outputPath],
        {
          cwd: dirname(getBeautifyEnginePath()),
          env: getSafeProcessEnv(),
          timeout: TIMEOUT_MS,
          maxBuffer: 8 * 1024 * 1024,
        },
      );
    } catch (error) {
      const details = error as {
        killed?: boolean;
        stderr?: string;
        stdout?: string;
      };
      if (details.killed) {
        throw new Error("Beautify timed out after 120 seconds.");
      }

      const output =
        `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
      const usefulLine = output
        .split("\n")
        .map((line) => line.trim())
        .find((line) => line.startsWith("Error"));
      throw new Error(
        usefulLine ?? "Could not parse this file as Lua source.",
      );
    }

    const outputBytes = await prependGeneratedHeader(outputPath);
    if (!outputBytes.byteLength) {
      throw new Error("Beautify returned an empty file.");
    }

    return {
      outputPath,
      outputName: `${inputName.replace(/\.lua$/i, "")}.beautify.lua`,
      outputBytes: outputBytes.byteLength,
    };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function deobfuscateLuaLegacy(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<DeobfuscationResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "legacy-deobf-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
  const outputPath = `${inputPath}.deobf.lua`;

  try {
    await writeFile(inputPath, fileBytes);

    let engineStdout = "";
    let engineStderr = "";
    try {
      const engineResult = await execFileAsync(
        process.env["PYTHON_EXECUTABLE"] ?? "python3",
        [getEnginePath(), inputPath],
        {
          cwd: dirname(getEnginePath()),
          env: getSafeProcessEnv(),
          timeout: TIMEOUT_MS,
          maxBuffer: 8 * 1024 * 1024,
        },
      );
      engineStdout = engineResult.stdout;
      engineStderr = engineResult.stderr;
    } catch (error) {
      const details = error as {
        killed?: boolean;
        stderr?: string;
        stdout?: string;
      };
      if (details.killed) {
        throw new Error("The legacy deobfuscation timed out after 120 seconds.");
      }

      const output =
        `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
      const usefulLine = output
        .split("\n")
        .map((line) => line.trim())
        .find(
          (line) =>
            line.startsWith("Could not") ||
            line.startsWith("Error") ||
            line.startsWith("Invalid") ||
            line.startsWith("Unhandled"),
        );
      throw new Error(
        usefulLine ?? "The legacy deobfuscation engine could not process this Lua file.",
      );
    }

    try {
      await execFileAsync(
        process.env["PYTHON_EXECUTABLE"] ?? "python3",
        [join(dirname(getEnginePath()), "clean_output.py"), outputPath],
        {
          cwd: dirname(getEnginePath()),
          env: getSafeProcessEnv(),
          timeout: 10_000,
          maxBuffer: 1 * 1024 * 1024,
        },
      );
    } catch {
      // Keep the generated Lua source if optional comment cleanup fails.
    }

    let outputBytes: Uint8Array;
    try {
      outputBytes = await readFile(outputPath);
    } catch {
      throw new Error(
        "The legacy engine could not reconstruct source from this file. Try &deobf for the newer Prometheus format.",
      );
    }
    if (!outputBytes.byteLength) {
      const diagnostic = `${engineStderr}\n${engineStdout}`
        .split("\n")
        .map((line) => line.trim())
        .find(
          (line) =>
            line.includes("error while loading shared libraries") ||
            line.startsWith("STDERR:") ||
            line.startsWith("Could not") ||
            line.startsWith("Error"),
        );
      throw new Error(
        diagnostic ?? "The legacy engine returned an empty file.",
      );
    }
    outputBytes = await prependGeneratedHeader(outputPath);

    return {
      outputPath,
      outputName: `${inputName.replace(/\.lua$/i, "")}.deobf2.lua`,
      outputBytes: outputBytes.byteLength,
    };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function deobfuscateIb2(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<Ib2Result> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "ib2-deobf-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
   const outputName = `${inputName.replace(/\.lua$/i, "")}.ib2.lua`;
  const outputPath = join(workingDir, outputName);
  const enginePath = getIb2EnginePath();

  try {
    await writeFile(inputPath, fileBytes);

    try {
      await execFileAsync(
        process.env["DOTNET_EXECUTABLE"] ?? "dotnet",
        [enginePath, inputPath, outputPath],
        {
          cwd: dirname(enginePath),
          env: getSafeProcessEnv(),
          timeout: TIMEOUT_MS,
          maxBuffer: 2 * 1024 * 1024,
        },
      );
    } catch (error) {
      const details = error as {
        killed?: boolean;
        stderr?: string;
        stdout?: string;
      };
      if (details.killed) {
        throw new Error("IB2 processing timed out after 120 seconds.");
      }

      const output = `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
      const usefulLine = output
        .split("\n")
        .map((line) => line.trim())
        .find(
          (line) =>
            line.startsWith("Error") ||
            line.startsWith("Invalid") ||
            line.startsWith("Unhandled"),
        );
      throw new Error(
        usefulLine ?? "The IB2 engine could not process this Lua file.",
      );
    }

    const outputBytes = await prependGeneratedHeader(outputPath);
    return {
      outputPath,
      outputName,
      outputBytes: outputBytes.byteLength,
    };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

function getIronveilEnginePath(): string {
  return join(dirname(fileURLToPath(import.meta.url)), "ironveil", "index.js");
}

export async function deobfuscateIronveil(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<IronveilResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "ironveil-deobf-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
  const outputName = `${inputName.replace(/\.lua$/i, "")}.ironveil.lua`;
  const outputPath = join(workingDir, outputName);

  try {
    await writeFile(inputPath, fileBytes);
    try {
      const require = createRequire(import.meta.url);
      const engine = require(getIronveilEnginePath()) as {
        deobfuscateFile?: (inputPath: string, outputPath: string) => unknown;
      };
      if (typeof engine.deobfuscateFile !== "function") {
        throw new Error("The Ironveil V1 engine is missing its file processor.");
      }
      engine.deobfuscateFile(inputPath, outputPath);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown engine error.";
      throw new Error(`Ironveil V1 could not process this Lua file: ${message}`);
    }

    const outputBytes = await prependGeneratedHeader(outputPath);
    return { outputPath, outputName, outputBytes: outputBytes.byteLength };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function deobfuscateMoonsec(
  fileName: string,
  fileBytes: Uint8Array,
  mode: MoonsecOutputMode,
): Promise<MoonsecResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "moonsec-deobf-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
  const outputName =
    mode === "dev"
       ? `${inputName.replace(/\.lua$/i, "")}.moonsec.lua`
      : `${inputName.replace(/\.lua$/i, "")}.moonsec.disassembly.txt`;
  const outputPath = join(workingDir, outputName);
  const assemblyPath = join(getMoonsecDirectory(), "publish", "MoonsecDeobfuscator.dll");
  const bytecodePath = join(workingDir, `${inputName}.luac`);

  try {
    await writeFile(inputPath, fileBytes);

    try {
      await execFileAsync(
        process.env["DOTNET_EXECUTABLE"] ?? "dotnet",
        [
          assemblyPath,
          `-${mode}`,
          "-i",
          inputPath,
          "-o",
          mode === "dev" ? bytecodePath : outputPath,
        ],
        {
          cwd: dirname(assemblyPath),
          env: getSafeProcessEnv(),
          timeout: TIMEOUT_MS,
          maxBuffer: 2 * 1024 * 1024,
        },
      );
    } catch (error) {
      const details = error as {
        killed?: boolean;
        stderr?: string;
        stdout?: string;
      };
      if (details.killed) {
        throw new Error("Moonsec processing timed out after 120 seconds.");
      }

      const output = `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
      const usefulLine = output
        .split("\n")
        .map((line) => line.trim())
        .find(
          (line) =>
            line.startsWith("Error") ||
            line.startsWith("Invalid") ||
            line.startsWith("Unhandled"),
        );
      throw new Error(
        usefulLine ?? "The Moonsec engine could not process this Lua file.",
      );
    }

    if (mode === "dev") {
      try {
        await execFileAsync(
          getBundledLua51Path(),
          [getBundledDecompilerScript(), bytecodePath, outputPath],
          {
            cwd: getMoonsecDirectory(),
            env: getSafeProcessEnv(),
            timeout: TIMEOUT_MS,
            maxBuffer: 2 * 1024 * 1024,
          },
        );
      } catch (error) {
        const details = error as {
          killed?: boolean;
          stderr?: string;
          stdout?: string;
        };
        if (details.killed) {
          throw new Error("Moonsec Lua decompilation timed out after 120 seconds.");
        }
        const output = `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
        throw new Error(
          output.split("\n").map((line) => line.trim()).find(Boolean) ??
            "Moonsec bytecode was produced, but it could not be converted to readable Lua.",
        );
      }
    }

    const outputBytes = await prependGeneratedHeader(outputPath);
    return { outputPath, outputName, outputBytes: outputBytes.byteLength, mode };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function deobfuscateMoonveil(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<MoonveilResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "moonveil-deobf-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
  const outputName = `${inputName.replace(/\.lua$/i, "")}.moonveil.lua`;
  const outputPath = join(workingDir, outputName);
  const engineDir = getMoonveilDirectory();

  try {
    await writeFile(inputPath, fileBytes);
    try {
      await execFileAsync(
        process.env["PYTHON_EXECUTABLE"] ?? "python3",
        ["moonveil_decompile.py", inputPath, outputPath],
        {
          cwd: engineDir,
          env: {
            ...getPythonEnv(),
            MOONVEIL_OUT_DIR: workingDir,
          },
          timeout: TIMEOUT_MS,
          maxBuffer: 4 * 1024 * 1024,
        },
      );
    } catch (error) {
      throw engineError(
        error,
        "The Moonveil engine could not process this Lua file.",
        "Moonveil processing timed out after 120 seconds.",
      );
    }

    let outputBytes: Uint8Array;
    try {
      outputBytes = await readFile(outputPath);
    } catch {
      throw new Error(
        "Moonveil did not recognize this file or could not reconstruct source. Moonveil may require a runtime trace for this build.",
      );
    }
    if (!outputBytes.byteLength) {
      throw new Error("The Moonveil engine returned an empty file.");
    }
    outputBytes = await prependGeneratedHeader(outputPath);

    return { outputPath, outputName, outputBytes: outputBytes.byteLength };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function deobfuscateLuauVmp(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<LuauVmpResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "luauvmp-deobf-"));
  const safeName = fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.lua";
  const inputName = safeName.toLowerCase().endsWith(".lua")
    ? safeName
    : `${safeName}.lua`;
  const inputPath = join(workingDir, inputName);
  const outputDir = join(workingDir, "recovered");
  const engineDir = getLuauVmpDirectory();

  try {
    await writeFile(inputPath, fileBytes);
    try {
      await execFileAsync(
        process.env["PYTHON_EXECUTABLE"] ?? "python3",
        [
          "-m",
          "luauvmp",
          "luraph-full",
          inputPath,
          "-o",
          outputDir,
          "--no-lua-expert",
          "--force",
        ],
        {
          cwd: engineDir,
          env: getPythonEnv(engineDir),
          timeout: TIMEOUT_MS,
          maxBuffer: 8 * 1024 * 1024,
        },
      );
    } catch (error) {
      throw engineError(
        error,
        "The Luau-VMP engine could not process this Lua file.",
        "Luau-VMP processing timed out after 120 seconds.",
      );
    }

    const candidates = [
      ["program.decompiled.luau", "luauvmp.lua"],
      ["program.pseudo.lua", "luauvmp.pseudo.lua"],
      ["embedded_main.luau", "luauvmp.embedded.luau"],
    ];
    let outputPath: string | undefined;
    let outputName = "";
    for (const [relativePath, candidateName] of candidates) {
      const candidatePath = join(outputDir, relativePath);
      try {
        const bytes = await readFile(candidatePath);
        if (bytes.byteLength) {
          outputPath = candidatePath;
          outputName = `${inputName.replace(/\.[^.]+$/i, "")}.${candidateName}`;
          break;
        }
      } catch {
        // Try the next output produced by the engine.
      }
    }

    if (!outputPath) {
      throw new Error(
        "Luau-VMP did not recognize this file or did not produce a readable output.",
      );
    }

    const outputBytes = await prependGeneratedHeader(outputPath);
    return { outputPath, outputName, outputBytes: outputBytes.byteLength };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function cleanupDeobfuscation(
  outputPath: string,
): Promise<void> {
  await rm(dirname(outputPath), { recursive: true, force: true });
}