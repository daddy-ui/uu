import re
import sys
from pathlib import Path


TRACE_COMMENT_PATTERNS = (
    re.compile(r"^\s*--\s*Deobfuscated via Trace Emulation\b", re.I),
    re.compile(r"^\s*--\s*=== String Constants ===\s*$", re.I),
    re.compile(r"^\s*--\s*(?:URL|Closure for|LOADSTRING|TRACE_PRINT)\b", re.I),
    re.compile(r"^\s*--\s*Loop detected:\s*\d+\s*iterations\s*$", re.I),
)


def clean_output(path: str) -> None:
    source = Path(path).read_text(encoding="utf-8", errors="replace")
    source = source.replace("\ufeff", "")
    cleaned = []
    previous_blank = False

    for line in source.splitlines():
        if any(pattern.search(line) for pattern in TRACE_COMMENT_PATTERNS):
            continue

        if not line.strip():
            if previous_blank:
                continue
            previous_blank = True
        else:
            previous_blank = False

        cleaned.append(line.rstrip())

    Path(path).write_text("\n".join(cleaned).rstrip() + "\n", encoding="utf-8")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("Usage: clean_output.py <lua-file>")
    clean_output(sys.argv[1])