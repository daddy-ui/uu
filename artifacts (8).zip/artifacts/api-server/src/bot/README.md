# Deobfuscator bot

The API server starts the Discord bot when `DISCORD_BOT_TOKEN` is available.

## Commands

Every command accepts one Lua/Luau attachment or a direct HTTP(S) URL:

- `&deobfuscate` / `/deobfuscate` — large-file Prometheus engine
- `&deobf2` / `/deobfuscate2` — legacy Prometheus engine
- `&ib2` — Ironbrew 2
- `&iv1` / `/ironveil` — Ironveil V1
- `&moonsec` / `/moonsec` — MoonSec V3
- `&moonveil` / `/moonveil` — uploaded Moonveil engine
- `&luauvmp` / `/luauvmp` — uploaded Luau-VMP/Luraph engine

Moonveil builds that derive keys from Roblox runtime state still need the
engine's trace workflow. Luau-VMP runs with `--no-lua-expert`, keeping the
processing local.