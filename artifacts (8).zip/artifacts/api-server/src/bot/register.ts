import { REST, Routes } from "discord.js";
import { slashCommands } from "./commands.js";
import { logger } from "../lib/logger.js";

export async function registerSlashCommands(clientId: string): Promise<void> {
  const token = (
    process.env["DISCORD_BOT_TOKEN_FRESH"] ??
    process.env["DISCORD_BOT_TOKEN"]
  )
    ?.trim()
    .replace(/^["']|["']$/g, "")
    .replace(/^Bot\s+/i, "")
    .trim();
  if (!token) {
    throw new Error("DISCORD_BOT_TOKEN is required");
  }

  const rest = new REST({ version: "10" }).setToken(token);

  try {
    logger.info("Registering slash commands...");
    await rest.put(Routes.applicationCommands(clientId), {
      body: slashCommands,
    });
    logger.info("Slash commands registered successfully.");
  } catch (err) {
    logger.error({ err }, "Failed to register slash commands");
  }
}
