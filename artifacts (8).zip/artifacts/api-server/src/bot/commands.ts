import {
  Attachment,
  AttachmentBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  Message,
  SlashCommandBuilder,
} from "discord.js";
import {
  cleanupDeobfuscation,
  deobfuscateIb2,
  deobfuscateIronveil,
  deobfuscateMoonsec,
  deobfuscateMoonveil,
  deobfuscateLuauVmp,
  deobfuscateLua,
  deobfuscateLuaLegacy,
  deobfuscateBeautify,
  type Ib2Result,
  type IronveilResult,
  type MoonsecOutputMode,
  type MoonveilResult,
  type LuauVmpResult,
  type BeautifyResult,
} from "./deobfuscator/runner.js";
import {
  cleanupEnvLogger,
  runEnvLogger,
} from "./envlogger/runner.js";

const MAX_INPUT_BYTES = 25 * 1024 * 1024;
const DOWNLOAD_TIMEOUT_MS = 120_000;

type InputSource = {
  name: string;
  url?: string;
  text?: string;
  size?: number;
};

type EngineResult =
  | Ib2Result
  | IronveilResult
  | MoonveilResult
  | LuauVmpResult
  | BeautifyResult
  | Awaited<ReturnType<typeof deobfuscateLua>>;
type Processor = (source: InputSource) => Promise<EngineResult>;

export const slashCommands = [
  new SlashCommandBuilder()
    .setName("help")
    .setDescription("List every deobfuscation command and what it does")
    .toJSON(),
  new SlashCommandBuilder()
    .setName("beautify")
    .setDescription("Pretty-print / format a Lua file")
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription("The Lua file to format")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the Lua file")
        .setRequired(false),
    )
    .toJSON(),
  new SlashCommandBuilder()
    .setName("get")
    .setDescription("Fetch a script from a URL and re-upload it as an attachment")
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the file")
        .setRequired(true),
    )
    .toJSON(),
  new SlashCommandBuilder()
    .setName("deobfuscate")
    .setDescription("Deobfuscate a Lua script with the large-file Prometheus engine")
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription("The obfuscated Lua file to process")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the obfuscated Lua file")
        .setRequired(false),
    )
    .toJSON(),
  new SlashCommandBuilder()
    .setName("deobfuscate2")
    .setDescription("Deobfuscate a Lua script with the original Prometheus engine")
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription("The obfuscated Lua file to process")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the obfuscated Lua file")
        .setRequired(false),
    )
    .toJSON(),
  new SlashCommandBuilder()
    .setName("moonsec")
    .setDescription("Deobfuscate a MoonSec V3 Lua script")
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription("The MoonSec V3 obfuscated Lua file")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the MoonSec V3 Lua file")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("mode")
        .setDescription("Choose readable Lua source or disassembly")
        .setRequired(false)
        .addChoices(
          { name: "Readable Lua source (.lua)", value: "dev" },
          { name: "Disassembly (.txt)", value: "dis" },
        ),
    )
    .toJSON(),
  new SlashCommandBuilder()
    .setName("ironveil")
    .setDescription("Deobfuscate an Ironveil V1 Lua script")
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription("The Ironveil V1 obfuscated Lua file")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the Ironveil V1 Lua file")
        .setRequired(false),
    )
    .toJSON(),
  new SlashCommandBuilder()
    .setName("moonveil")
    .setDescription("Deobfuscate a Moonveil-protected Lua script")
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription("The Moonveil-protected Lua file")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the Moonveil Lua file")
        .setRequired(false),
    )
    .toJSON(),
  new SlashCommandBuilder()
    .setName("luauvmp")
    .setDescription("Deobfuscate a Luau VMP or Luraph-protected script")
    .addAttachmentOption((option) =>
      option
        .setName("file")
        .setDescription("The protected Luau file")
        .setRequired(false),
    )
    .addStringOption((option) =>
      option
        .setName("url")
        .setDescription("A direct URL to the protected Luau file")
        .setRequired(false),
    )
    .toJSON(),
];

function errorEmbed(message: string): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0xff4d6d)
    .setTitle("Deobfuscation failed")
    .setDescription(message);
}

type CommandDoc = {
  prefix: string;
  slash: string;
  summary: string;
  usage: string;
};

const COMMAND_DOCS: CommandDoc[] = [
  {
    prefix: "&deobfuscate, &deobf",
    slash: "/deobfuscate",
    summary: "Prometheus/WeAreDevs engine, tuned for large files.",
    usage: "Attach a .lua file, or pass a direct URLL.",
  },
  {
    prefix: "&deobf2, &deobfuscate2",
    slash: "/deobfuscate2",
    summary: "Original Prometheus engine. Try this if the main one mangles a file.",
    usage: "Attach a .lua file, or pass a direct URL.",
  },
  {
    prefix: "&moonsec or &moonsec dis",
    slash: "/moonsec",
    summary: "MoonSec V3 engine. add `dis` for raw disassembly.",
    usage: "&moonsec (readable) or &moonsec dis (disassembly)",
  },
  {
    prefix: "&ib2",
    slash: "—",
    summary: "IronBrew2 engine.",
    usage: "Attach a .lua file, or pass a direct URL.",
  },
  {
    prefix: "&iv1, &ironveil",
    slash: "/ironveil",
    summary: "Ironveil V1 engine.",
    usage: "Attach a .lua file, or pass a direct URL.",
  },
  {
    prefix: "&moonveil, &mv",
    slash: "/moonveil",
    summary: "Moonveil engine",
    usage: "Attach a .lua file, or pass a direct URL.",
  },
  {
    prefix: "&luauvmp, &luraph",
    slash: "/luauvmp",
    summary: "Luraph, not supported yet ",
    usage: "Attach a .lua file, or pass a direct URL.",
  },
  {
    prefix: "&l, &envlogger",
    slash: "—",
    summary: "Run the isolated Roblox/Luau EnvLogger benchmark.",
    usage: "Attach one .lua or .luau file.",
  },
  {
    prefix: "&beautify, &bf",
    slash: "/beautify",
    summary: "Pretty-print a Lua file. Formatting only, no deobfuscation.",
    usage: "Attach a .lua file, or pass a direct URL.",
  },
  {
    prefix: "&get",
    slash: "/get",
    summary: "Fetch a script from a URL and re-upload it as-is.",
    usage: "&get <url>",
  },
];

function helpEmbed(): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(0x6d5dfc)
    .setTitle("Deobfuscator Commands")
    .setDescription(
      "all deobfuscator engines are below (25 MB limit).",
    );

  for (const doc of COMMAND_DOCS) {
    const name = doc.slash === "—" ? doc.prefix : `${doc.prefix}  •  ${doc.slash}`;
    embed.addFields({
      name,
      value: `${doc.summary}\n-# ${doc.usage}`,
    });
  }

  return embed;
}

function cleanUrl(rawUrl: string): string {
  const trimmed = rawUrl
    .trim()
    .replace(/^<|>$/g, "")
    .replace(/[),.;!?]+$/g, "");

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    throw new Error("That does not look like a valid file URL.");
  }

  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("Only http:// and https:// file links are supported.");
  }
  if (parsed.username || parsed.password) {
    throw new Error("Links containing embedded credentials are not supported.");
  }

  return parsed.toString();
}

function extractUrl(text: string): string | undefined {
  const match = text.match(/https?:\/\/[^\s<>()]+/i);
  return match ? cleanUrl(match[0]) : undefined;
}

function fileNameFromUrl(url: string): string {
  try {
    const pathname = new URL(url).pathname;
    const candidate = decodeURIComponent(pathname.split("/").pop() ?? "");
    const safe = candidate.replace(/[^a-zA-Z0-9._-]/g, "_");
    return safe || "script.lua";
  } catch {
    return "script.lua";
  }
}

function sourceFromAttachment(attachment: Attachment): InputSource {
  return { name: attachment.name || "script.lua", url: attachment.url, size: attachment.size };
}

const CODE_BLOCK_PATTERN = /```(?:[a-zA-Z0-9_+-]*\n)?([\s\S]+?)```/;

function extractCodeBlock(text: string): string | undefined {
  const match = text.match(CODE_BLOCK_PATTERN);
  if (!match) return undefined;
  const body = match[1]?.replace(/\n$/, "");
  return body && body.trim().length > 0 ? body : undefined;
}

function sourceFromMessageContentOnly(message: Message): InputSource | undefined {
  const attachment = message.attachments.first();
  if (attachment) return sourceFromAttachment(attachment);

  const codeBlock = extractCodeBlock(message.content);
  if (codeBlock !== undefined) return { name: "script.lua", text: codeBlock };

  const url = extractUrl(message.content);
  return url ? { name: fileNameFromUrl(url), url } : undefined;
}

async function fetchReferencedMessage(message: Message): Promise<Message | undefined> {
  if (!message.reference) return undefined;
  try {
    return await message.fetchReference();
  } catch {
    return undefined;
  }
}

async function sourceFromMessage(message: Message): Promise<InputSource | undefined> {
  const direct = sourceFromMessageContentOnly(message);
  if (direct) return direct;

  const referenced = await fetchReferencedMessage(message);
  if (!referenced) return undefined;

  return sourceFromMessageContentOnly(referenced);
}

function sourceFromInteraction(
  interaction: ChatInputCommandInteraction,
): InputSource | undefined {
  const attachment = interaction.options.getAttachment("file", false);
  if (attachment) return sourceFromAttachment(attachment);

  const rawUrl = interaction.options.getString("url", false);
  if (!rawUrl) return undefined;
  const url = cleanUrl(rawUrl);
  return { name: fileNameFromUrl(url), url };
}

async function fetchWithHeaders(url: string): Promise<Response> {
  const cloudflareTransientStatuses = new Set([520, 521, 522, 524]);
  let lastResponse: Response | undefined;

  for (let attempt = 0; attempt <= 1; attempt += 1) {
    lastResponse = await fetch(url, {
      redirect: "manual",
      signal: AbortSignal.timeout(DOWNLOAD_TIMEOUT_MS),
      headers: {
        "user-agent":
          "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
        accept: "text/plain,text/x-lua,application/octet-stream,*/*",
      },
    });

    if (!cloudflareTransientStatuses.has(lastResponse.status)) break;
    if (attempt === 0) await new Promise((resolve) => setTimeout(resolve, 750));
  }

  return lastResponse!;
}

async function downloadSource(source: InputSource): Promise<Uint8Array> {
  if (source.size !== undefined && source.size > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  if (source.text !== undefined) {
    const bytes = new TextEncoder().encode(source.text);
    if (bytes.byteLength > MAX_INPUT_BYTES) {
      throw new Error("That Lua file is too large. The limit is 25 MB.");
    }
    return bytes;
  }

  if (!source.url) {
    throw new Error("No file, URL, or code block found for that source.");
  }

  let currentUrl = cleanUrl(source.url);
  let response: Response | undefined;

  for (let redirect = 0; redirect <= 3; redirect += 1) {
    response = await fetchWithHeaders(currentUrl);

    if (response.status < 300 || response.status >= 400) break;
    const location = response.headers.get("location");
    if (!location) throw new Error("The file link returned an invalid redirect.");
    currentUrl = cleanUrl(new URL(location, currentUrl).toString());
  }

  if (!response || response.status >= 300 && response.status < 400) {
    throw new Error("The file link redirected too many times.");
  }
  if (!response.ok) {
    const cloudflareTransientStatuses = new Set([520, 521, 522, 524]);
    if (cloudflareTransientStatuses.has(response.status)) {
      throw new Error(
        `The host returned a Cloudflare error (HTTP ${response.status}) even after a retry. The origin server is likely down or blocking this request — try the link directly in a browser to confirm.`,
      );
    }
    throw new Error(`Could not download the file link (HTTP ${response.status}).`);
  }

  const declaredLength = Number(response.headers.get("content-length") ?? 0);
  if (declaredLength > MAX_INPUT_BYTES) {
    throw new Error("That Lua file is too large. The limit is 25 MB.");
  }

  if (!response.body) {
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength > MAX_INPUT_BYTES) {
      throw new Error("That Lua file is too large. The limit is 25 MB.");
    }
    return bytes;
  }

  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      total += part.value.byteLength;
      if (total > MAX_INPUT_BYTES) {
        throw new Error("That Lua file is too large. The limit is 25 MB.");
      }
      chunks.push(part.value);
    }
  } finally {
    reader.releaseLock();
  }

  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

async function processSource(
  source: InputSource,
  processor: (name: string, bytes: Uint8Array) => Promise<EngineResult>,
): Promise<EngineResult> {
  return processor(source.name, await downloadSource(source));
}

function completeEmbed(
  fileName: string,
  outputBytes: number,
  outputDescription = "The reconstructed Lua source is attached below.",
  title = "Deobfuscation complete",
): EmbedBuilder {
  return new EmbedBuilder()
    .setColor(0x6d5dfc)
    .setTitle(title)
    .setDescription(`Processed \`${fileName}\`. ${outputDescription}`)
    .setFooter({ text: `${outputBytes.toLocaleString()} bytes` });
}

function missingSourceMessage(command: string): string {
  return `Provide one Lua attachment, a direct file URL, or a \`\`\`code block\`\`\` with \`${command}\` — or reply to a message that has one.`;
}

async function handleMessageSource(
  message: Message,
  command: string,
  status: string,
  processor: Processor,
  outputDescription: (result: EngineResult) => string = () =>
    "The reconstructed Lua source is attached below.",
  title = "Deobfuscation complete",
): Promise<void> {
  const source = await sourceFromMessage(message);
  if (!source) {
    await message.reply(missingSourceMessage(command));
    return;
  }

  const loading = await message.reply(status);
  let outputPath: string | undefined;
  try {
    const result = await processor(source);
    outputPath = result.outputPath;
    await loading.edit({
      content: "",
      embeds: [completeEmbed(source.name, result.outputBytes, outputDescription(result), title)],
      files: [new AttachmentBuilder(result.outputPath).setName(result.outputName)],
    });
  } catch (err) {
    const messageText = err instanceof Error ? err.message : "Unknown error occurred.";
    await loading.edit({ content: "", embeds: [errorEmbed(messageText)] });
  } finally {
    if (outputPath) await cleanupDeobfuscation(outputPath);
  }
}

async function handleInteractionSource(
  interaction: ChatInputCommandInteraction,
  processor: Processor,
  outputDescription: (result: EngineResult) => string = () =>
    "The reconstructed Lua source is attached below.",
  title = "Deobfuscation complete",
): Promise<void> {
  const source = sourceFromInteraction(interaction);
  await interaction.deferReply();

  if (!source) {
    await interaction.editReply({
      embeds: [errorEmbed("Provide either a Lua attachment or a direct file URL.")],
    });
    return;
  }

  let outputPath: string | undefined;
  try {
    const result = await processor(source);
    outputPath = result.outputPath;
    await interaction.editReply({
      embeds: [completeEmbed(source.name, result.outputBytes, outputDescription(result), title)],
      files: [new AttachmentBuilder(result.outputPath).setName(result.outputName)],
    });
  } catch (err) {
    const messageText = err instanceof Error ? err.message : "Unknown error occurred.";
    await interaction.editReply({ embeds: [errorEmbed(messageText)] });
  } finally {
    if (outputPath) await cleanupDeobfuscation(outputPath);
  }
}

const processPrometheus: Processor = (source) =>
  processSource(source, deobfuscateLua);
const processPrometheusLegacy: Processor = (source) =>
  processSource(source, deobfuscateLuaLegacy);
const processIb2: Processor = (source) =>
  processSource(source, deobfuscateIb2);
const processIronveil: Processor = (source) =>
  processSource(source, deobfuscateIronveil);
const processMoonveil: Processor = (source) =>
  processSource(source, deobfuscateMoonveil);
const processLuauVmp: Processor = (source) =>
  processSource(source, deobfuscateLuauVmp);
const processBeautify: Processor = (source) =>
  processSource(source, deobfuscateBeautify);

export async function handleSlashDeobfuscate(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await handleInteractionSource(interaction, processPrometheus);
}

export async function handlePrefixDeobfuscate(message: Message): Promise<void> {
  await handleMessageSource(
    message,
    "&deobfuscate",
    "Processing the Lua file. This can take up to 120 seconds...",
    processPrometheus,
  );
}

export async function handlePrefixDeobfuscate2(message: Message): Promise<void> {
  await handleMessageSource(
    message,
    "&deobf2",
    "Processing the Lua file with the original Prometheus engine. This can take up to 120 seconds...",
    processPrometheusLegacy,
  );
}

export async function handleSlashDeobfuscate2(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await handleInteractionSource(interaction, processPrometheusLegacy);
}

export async function handlePrefixIb2(message: Message): Promise<void> {
  await handleMessageSource(
    message,
    "&ib2",
    "Processing the IB2 Lua file. This can take up to 120 seconds...",
    processIb2,
    () => "The deobfuscated Lua 5.4 bytecode is attached below.",
  );
}

export async function handlePrefixIronveil(message: Message): Promise<void> {
  await handleMessageSource(
    message,
    "&iv1",
    "Processing the Ironveil V1 Lua file. This can take up to 120 seconds...",
    processIronveil,
  );
}

export async function handleSlashIronveil(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await handleInteractionSource(interaction, processIronveil);
}

export async function handleSlashMoonveil(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await handleInteractionSource(
    interaction,
    processMoonveil,
    () =>
      "The Moonveil reconstruction is attached below. Environment-locked builds may require a runtime trace.",
  );
}

export async function handlePrefixMoonveil(message: Message): Promise<void> {
  await handleMessageSource(
    message,
    "&moonveil",
    "Processing the Moonveil Lua file. This can take up to 120 seconds...",
    processMoonveil,
    () =>
      "The Moonveil reconstruction is attached below. Environment-locked builds may require a runtime trace.",
  );
}

export async function handleSlashLuauVmp(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await handleInteractionSource(
    interaction,
    processLuauVmp,
    () => "The local Luau-VMP reconstruction is attached below.",
  );
}

export async function handlePrefixLuauVmp(message: Message): Promise<void> {
  await handleMessageSource(
    message,
    "&luauvmp",
    "Processing the Luau VMP file locally. This can take up to 120 seconds...",
    processLuauVmp,
    () => "The local Luau-VMP reconstruction is attached below.",
  );
}

function moonsecDescription(mode: MoonsecOutputMode): string {
  return mode === "dev"
    ? "The readable Lua source reconstructed from MoonSec bytecode is attached below."
    : "The readable MoonSec disassembly is attached below.";
}

export async function handleSlashMoonsec(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const mode = (interaction.options.getString("mode", false) ?? "dev") as MoonsecOutputMode;
  await handleInteractionSource(
    interaction,
    (source) => processSource(source, (name, bytes) => deobfuscateMoonsec(name, bytes, mode)),
    () => moonsecDescription(mode),
  );
}

export async function handlePrefixMoonsec(
  message: Message,
  mode: MoonsecOutputMode = "dev",
): Promise<void> {
  await handleMessageSource(
    message,
    mode === "dis" ? "&moonsec dis" : "&moonsec",
    "Processing the MoonSec V3 Lua file. This can take up to 120 seconds...",
    (source) => processSource(source, (name, bytes) => deobfuscateMoonsec(name, bytes, mode)),
    () => moonsecDescription(mode),
  );
}

export async function handleSlashHelp(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await interaction.reply({ embeds: [helpEmbed()] });
}

export async function handlePrefixHelp(message: Message): Promise<void> {
  await message.reply({ embeds: [helpEmbed()] });
}

export async function handleSlashBeautify(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  await handleInteractionSource(
    interaction,
    processBeautify,
    () => "The formatted Lua source is attached below.",
    "Beautify complete",
  );
}

export async function handlePrefixBeautify(message: Message): Promise<void> {
  await handleMessageSource(
    message,
    "&beautify",
    "Formatting the Lua file...",
    processBeautify,
    () => "The formatted Lua source is attached below.",
    "Beautify complete",
  );
}

function ensureLuaExtension(name: string): string {
  return /\.lua$/i.test(name) ? name : `${name}.lua`;
}

async function fetchAndReupload(source: InputSource): Promise<{
  bytes: Uint8Array;
  fileName: string;
}> {
  const bytes = await downloadSource(source);
  return { bytes, fileName: ensureLuaExtension(source.name) };
}

export async function handleSlashGet(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const rawUrl = interaction.options.getString("url", true);
  await interaction.deferReply();

  let source: InputSource;
  try {
    const url = cleanUrl(rawUrl);
    source = { name: fileNameFromUrl(url), url };
  } catch (err) {
    const messageText = err instanceof Error ? err.message : "Invalid URL.";
    await interaction.editReply({ embeds: [errorEmbed(messageText)] });
    return;
  }

  try {
    const { bytes, fileName } = await fetchAndReupload(source);
    await interaction.editReply({
      embeds: [completeEmbed(fileName, bytes.byteLength, "Fetched as-is, no processing applied.", "File fetched")],
      files: [new AttachmentBuilder(Buffer.from(bytes)).setName(fileName)],
    });
  } catch (err) {
    const messageText = err instanceof Error ? err.message : "Could not download that URL.";
    await interaction.editReply({ embeds: [errorEmbed(messageText)] });
  }
}

export async function handlePrefixGet(message: Message): Promise<void> {
  let rawUrl = extractUrl(message.content);
  if (!rawUrl) {
    const referenced = await fetchReferencedMessage(message);
    if (referenced) rawUrl = extractUrl(referenced.content);
  }
  if (!rawUrl) {
    await message.reply(
      "Provide a direct file URL with `&get <url>`, or reply to a message containing one.",
    );
    return;
  }

  let source: InputSource;
  try {
    source = { name: fileNameFromUrl(rawUrl), url: rawUrl };
  } catch (err) {
    const messageText = err instanceof Error ? err.message : "Invalid URL.";
    await message.reply({ embeds: [errorEmbed(messageText)] });
    return;
  }

  const loading = await message.reply("Fetching the file...");
  try {
    const { bytes, fileName } = await fetchAndReupload(source);
    await loading.edit({
      content: "",
      embeds: [completeEmbed(fileName, bytes.byteLength, "Fetched as-is, no processing applied.", "File fetched")],
      files: [new AttachmentBuilder(Buffer.from(bytes)).setName(fileName)],
    });
  } catch (err) {
    const messageText = err instanceof Error ? err.message : "Could not download that URL.";
    await loading.edit({ content: "", embeds: [errorEmbed(messageText)] });
  }
}

function envLoggerEmbed(
  fileName: string,
  summary: string,
  warnings: string[],
  outputBytes: number,
): EmbedBuilder {
  const warningText =
    warnings.length > 0
      ? `\n\nWarnings:\n${warnings.map((warning) => `• ${warning}`).join("\n")}`
      : "";

  return new EmbedBuilder()
    .setColor(warnings.length > 0 ? 0xf0a202 : 0x45c486)
    .setTitle("EnvLogger report complete")
    .setDescription(
      `Analyzed \`${fileName}\` with the uploaded Roblox/Luau EnvLogger.\n\n${summary}${warningText}\n\nThe report was generated inside an isolated Lune process; the bot does not expose its own server environment to the uploaded script.`,
    )
    .setFooter({ text: `${outputBytes.toLocaleString()} report bytes attached` });
}

export async function handlePrefixEnvLogger(message: Message): Promise<void> {
  const source = await sourceFromMessage(message);
  if (!source) {
    await message.reply(
      "Provide one `.lua`/`.luau` attachment, a direct file URL, or a ```code block``` with `&l` — or reply to a message that has one.",
    );
    return;
  }

  if (source.size !== undefined && source.size > MAX_INPUT_BYTES) {
    await message.reply("That Luau file is too large. The limit is 8 MB.");
    return;
  }

  const loading = await message.reply(
    "Running the EnvLogger benchmark in an isolated Luau process. This may take up to 25 seconds...",
  );
  const outputPaths: string[] = [];

  try {
    const bytes = await downloadSource(source);
    if (bytes.byteLength > 8 * 1024 * 1024) {
      throw new Error("That Luau file is too large. The limit is 8 MB.");
    }
    const result = await runEnvLogger(source.name, bytes);
    outputPaths.push(...result.artifacts.map((artifact) => artifact.outputPath));
    const outputBytes = result.artifacts.reduce(
      (total, artifact) => total + artifact.outputBytes,
      0,
    );

    await loading.edit({
      content: "",
      embeds: [
        envLoggerEmbed(
          source.name,
          result.summary,
          result.warnings,
          outputBytes,
        ),
      ],
      files: result.artifacts.map((artifact) =>
        new AttachmentBuilder(artifact.outputPath).setName(artifact.outputName),
      ),
    });
  } catch (error) {
    const errorMessage =
      error instanceof Error ? error.message : "Unknown EnvLogger error.";
    await loading.edit({
      content: "",
      embeds: [errorEmbed(`EnvLogger failed: ${errorMessage}`)],
    });
  } finally {
    await Promise.all(outputPaths.map((outputPath) => cleanupEnvLogger(outputPath)));
  }
}