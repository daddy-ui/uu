const fs = require("node:fs");
const path = require("node:path");

const [, , inputPath, outputPath] = process.argv;

if (!inputPath || !outputPath) {
  process.stderr.write("Usage: runner.js <input.lua> <output.lua>\n");
  process.exit(2);
}

if (!fs.existsSync(inputPath)) {
  process.stderr.write("The Prometheus input file does not exist.\n");
  process.exit(2);
}

process.argv = [process.argv[0], path.join(__dirname, "main.js"), inputPath, outputPath];
console.log = () => {};
console.error = (...args) => {
  process.stderr.write(`${args.join(" ")}\n`);
};

require("./main.js");