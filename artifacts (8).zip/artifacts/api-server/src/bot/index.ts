import {
  Client,
  GatewayIntentBits,
  Events,
  ChatInputCommandInteraction,
  Message,
} from "discord.js";
import {
  handlePrefixDeobfuscate,
  handlePrefixDeobfuscate2,
  handlePrefixIb2,
  handlePrefixIronveil,
  handlePrefixMoonsec,
  handlePrefixMoonveil,
  handlePrefixLuauVmp,
  handlePrefixHelp,
  handlePrefixEnvLogger,
  handlePrefixBeautify,
  handlePrefixGet,
  handleSlashDeobfuscate,
  handleSlashDeobfuscate2,
  handleSlashIronveil,
  handleSlashMoonsec,
  handleSlashMoonveil,
  handleSlashLuauVmp,
  handleSlashHelp,
  handleSlashBeautify,
  handleSlashGet,
} from "./commands.js";
import { registerSlashCommands } from "./register.js";
import { logger } from "../lib/logger.js";

const PREFIX = "&";

function normalizeToken(rawToken: string | undefined): string | undefined {
  return rawToken
    ?.trim()
    .replace(/^["']|["']$/g, "")
    .replace(/^Bot\s+/i, "")
    .trim();
}

async function verifyDiscordToken(token: string): Promise<boolean> {
  const response = await fetch("https://discord.com/api/v10/users/@me", {
    headers: { Authorization: `Bot ${token}` },
  });

  if (response.ok) {
    return true;
  }

  logger.error(
    {
      discordStatus: response.status,
      tokenLength: token.length,
      tokenSegments: token.split(".").length,
    },
    "Discord rejected DISCORD_BOT_TOKEN during REST preflight; the bot will not start",
  );
  return false;
}

export function startBot(): void {
  const token = normalizeToken(
    process.env["DISCORD_BOT_TOKEN_FRESH"] ??
      process.env["DISCORD_BOT_TOKEN"],
  );

  if (!token) {
    logger.error("DISCORD_BOT_TOKEN is not set — bot will not start.");
    return;
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
    ],
  });

  client.once(Events.ClientReady, async (c) => {
    logger.info(`Discord bot ready: ${c.user.tag}`);
    await registerSlashCommands(c.user.id);
  });

  // Handle slash commands
  client.on(Events.InteractionCreate, async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const cmd = interaction as ChatInputCommandInteraction;

    if (cmd.commandName === "help") {
      await handleSlashHelp(cmd);
    } else if (cmd.commandName === "deobfuscate") {
      await handleSlashDeobfuscate(cmd);
    } else if (cmd.commandName === "deobfuscate2") {
      await handleSlashDeobfuscate2(cmd);
    } else if (cmd.commandName === "moonsec") {
      await handleSlashMoonsec(cmd);
    } else if (cmd.commandName === "ironveil") {
      await handleSlashIronveil(cmd);
    } else if (cmd.commandName === "moonveil") {
      await handleSlashMoonveil(cmd);
    } else if (cmd.commandName === "luauvmp") {
      await handleSlashLuauVmp(cmd);
    } else if (cmd.commandName === "beautify") {
      await handleSlashBeautify(cmd);
    } else if (cmd.commandName === "get") {
      await handleSlashGet(cmd);
    }
  });

  // Handle prefix commands with Lua attachments
  client.on(Events.MessageCreate, async (message: Message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(PREFIX)) return;

    const args = message.content
      .slice(PREFIX.length)
      .trim()
      .split(/\s+/);
    const command = args[0]?.toLowerCase();

    if (command === "help" || command === "commands") {
      await handlePrefixHelp(message);
    } else if (command === "deobfuscate" || command === "deobf") {
      await handlePrefixDeobfuscate(message);
    } else if (command === "deobfuscate2" || command === "deobf2") {
      await handlePrefixDeobfuscate2(message);
    } else if (command === "l" || command === "envlogger") {
      await handlePrefixEnvLogger(message);
    } else if (command === "ib2") {
      await handlePrefixIb2(message);
    } else if (command === "iv1" || command === "ironveil") {
      await handlePrefixIronveil(message);
    } else if (command === "moonsec") {
      const mode = args[1]?.toLowerCase();
      await handlePrefixMoonsec(
        message,
        mode === "dis" || mode === "disassembly" ? "dis" : "dev",
      );
    } else if (command === "moonveil" || command === "mv") {
      await handlePrefixMoonveil(message);
    } else if (command === "luauvmp" || command === "luraph") {
      await handlePrefixLuauVmp(message);
    } else if (command === "beautify" || command === "bf") {
      await handlePrefixBeautify(message);
    } else if (command === "get") {
      await handlePrefixGet(message);
    }
  });

  void verifyDiscordToken(token)
    .then((valid) => {
      if (!valid) return;
      return client.login(token).catch((err) => {
        logger.error({ err }, "Failed to login to Discord Gateway");
      });
    })
    .catch((err) => {
      logger.error({ err }, "Could not reach Discord for token preflight");
    });
}
