import { execFile } from "node:child_process";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);
const MAX_INPUT_BYTES = 8 * 1024 * 1024;
const MAX_OUTPUT_BYTES = 8 * 1024 * 1024;
const TIMEOUT_MS = 22_000;

export interface EnvLoggerArtifact {
  outputPath: string;
  outputName: string;
  outputBytes: number;
}

export interface EnvLoggerResult {
  artifacts: EnvLoggerArtifact[];
  summary: string;
  warnings: string[];
}

type EnvLoggerReport = {
  success?: boolean;
  counts?: Record<string, number>;
  overflow?: boolean;
};

function getEnvLoggerRoot(): string {
  return join(dirname(fileURLToPath(import.meta.url)), "envlogger");
}

function getSafeProcessEnv(): NodeJS.ProcessEnv {
  return {
    PATH: process.env["PATH"] ?? "",
    HOME: process.env["HOME"] ?? "/tmp",
    LANG: "C.UTF-8",
    LC_ALL: "C.UTF-8",
    TMPDIR: process.env["TMPDIR"] ?? "/tmp",
  };
}

function safeFileName(fileName: string): string {
  return fileName.replace(/[^a-zA-Z0-9._-]/g, "_") || "script.luau";
}

function formatSummary(report: EnvLoggerReport): string {
  const counts = report.counts ?? {};
  const countText = Object.entries(counts)
    .filter(([, value]) => typeof value === "number")
    .map(([key, value]) => `${key}: ${value}`)
    .join(", ");
  const status = report.success === false ? "target ended with an error" : "target completed";
  const overflow = report.overflow ? " Event limit was reached." : "";
  return `${status}.${countText ? ` Events — ${countText}.` : ""}${overflow}`;
}

function collectReportNames(inputName: string): string[] {
  return [
    `${inputName}.envlog.txt`,
    `${inputName}.envlog.json`,
    `${inputName}.replay.lua`,
    `${inputName}.reconstructed.lua`,
  ];
}

function countMatches(source: string, pattern: RegExp): number {
  return source.match(pattern)?.length ?? 0;
}

function createStaticReport(
  inputName: string,
  source: string,
  reason: string,
): {
  text: string;
  json: string;
  replay: string;
  reconstructed: string;
  summary: string;
} {
  const dependencies = [
    ...new Set(
      [...source.matchAll(/require\s*\(\s*["']([^"']+)["']\s*\)/g)].map(
        (match) => match[1],
      ),
    ),
  ];
  const executorApis = [
    ...new Set(
      [
        ...source.matchAll(
          /\b(getgenv|request|http_request|syn\.request|writefile|readfile|isfile|makefolder|hookfunction|getgc|getconnections|identifyexecutor|setclipboard|queue_on_teleport)\b/g,
        ),
      ].map((match) => match[1]),
    ),
  ];
  const robloxApis = [
    ...new Set(
      [
        ...source.matchAll(
          /\b(game:GetService|Instance\.new|Enum\.[A-Za-z0-9_.]+|Vector[234]|CFrame|UDim2|Color3|Ray)\b/g,
        ),
      ].map((match) => match[1]),
    ),
  ];
  const registrationCount = countMatches(source, /\bregister\s*\(/g);
  const lineCount = source.length === 0 ? 0 : source.split(/\r?\n/).length;
  const json = {
    target: inputName,
    success: false,
    static_analysis: true,
    reason,
    source_bytes: Buffer.byteLength(source, "utf8"),
    source_lines: lineCount,
    benchmark_registrations: registrationCount,
    dependencies,
    executor_apis: executorApis,
    roblox_apis: robloxApis,
  };
  const summary =
    `static analysis only (${json.source_bytes.toLocaleString()} bytes, ${lineCount.toLocaleString()} lines). ` +
    `Detected ${registrationCount.toLocaleString()} benchmark registrations, ` +
    `${dependencies.length} module dependencies, ${executorApis.length} executor APIs, ` +
    `and ${robloxApis.length} Roblox API references.`;
  const text = [
    `EnvLogger static report: ${inputName}`,
    "",
    "The target was not executed. This report is a safe fallback for large or unsupported scripts.",
    `Reason: ${reason}`,
    "",
    `Source bytes: ${json.source_bytes}`,
    `Source lines: ${lineCount}`,
    `Benchmark registrations: ${registrationCount}`,
    `Module dependencies: ${dependencies.join(", ") || "none detected"}`,
    `Executor APIs: ${executorApis.join(", ") || "none detected"}`,
    `Roblox APIs: ${robloxApis.join(", ") || "none detected"}`,
    "",
    "No runtime pass/fail score is claimed.",
    "",
  ].join("\n");
  const replay = [
    `-- EnvLogger static fallback for ${inputName}`,
    `-- The target was not executed: ${reason}`,
    "-- No replay events are available.",
    "",
  ].join("\n");

  return {
    text,
    json: JSON.stringify(json, null, 2),
    replay,
    reconstructed: source,
    summary,
  };
}

async function writeStaticReports(
  outputDir: string,
  inputName: string,
  source: string,
  reason: string,
): Promise<{ summary: string; warnings: string[] }> {
  const report = createStaticReport(inputName, source, reason);
  await mkdir(outputDir, { recursive: true });
  const names = collectReportNames(inputName);
  await Promise.all([
    writeFile(join(outputDir, names[0]), report.text),
    writeFile(join(outputDir, names[1]), report.json),
    writeFile(join(outputDir, names[2]), report.replay),
    writeFile(join(outputDir, names[3]), report.reconstructed),
  ]);
  return {
    summary: report.summary,
    warnings: ["Runtime execution was skipped; this is a static fallback report."],
  };
}

function describeExecutionError(error: unknown): string {
  const details = error as {
    killed?: boolean;
    signal?: string;
    stderr?: string;
    stdout?: string;
  };
  if (details.killed || details.signal) {
    return "the runtime exceeded its 18-second execution limit";
  }
  const output = `${details.stderr ?? ""}\n${details.stdout ?? ""}`.trim();
  return (
    output
      .split("\n")
      .map((line) => line.trim())
      .find(
        (line) =>
          line.startsWith("error:") ||
          line.startsWith("Error") ||
          line.startsWith("Failed") ||
          line.startsWith("EnvLogger"),
      ) ?? "the runtime rejected or could not execute the target"
  );
}

export async function runEnvLogger(
  fileName: string,
  fileBytes: Uint8Array,
): Promise<EnvLoggerResult> {
  if (fileBytes.byteLength > MAX_INPUT_BYTES) {
    throw new Error("That Luau file is too large. The limit is 8 MB.");
  }

  const workingDir = await mkdtemp(join(tmpdir(), "envlogger-"));
  const inputName = safeFileName(fileName);
  const inputPath = join(workingDir, inputName);
  const outputDir = join(workingDir, "reports");
  const targetPath = join(outputDir, inputName);
  const envLoggerRoot = getEnvLoggerRoot();
  const scriptPath = join(envLoggerRoot, "EnvLogger.luau");
  const apiPath = join(envLoggerRoot, "api", "api.json");

  try {
    await writeFile(inputPath, fileBytes);

    const source = new TextDecoder().decode(fileBytes);
    const reportNames = collectReportNames(inputName);
    let fallback: { summary: string; warnings: string[] } | undefined;
    let processWarning: string | undefined;
    try {
      await execFileAsync(
        "lune",
        [
          "run",
          scriptPath,
          "--",
          inputPath,
          `--out=${outputDir}`,
          `--api=${apiPath}`,
          "--max-events=8000",
          "--max-ops=5000000",
          "--max-seconds=18",
        ],
        {
          cwd: envLoggerRoot,
          env: getSafeProcessEnv(),
          timeout: TIMEOUT_MS,
          maxBuffer: 2 * 1024 * 1024,
        },
      );
    } catch (error) {
      const existingReports = await Promise.all(
        reportNames.map(async (outputName) => {
          try {
            await readFile(join(outputDir, outputName));
            return true;
          } catch {
            return false;
          }
        }),
      );
      const executionError = describeExecutionError(error);
      if (existingReports.some(Boolean)) {
        processWarning =
          `EnvLogger exited after producing partial real reports: ${executionError}`;
      } else {
        fallback = await writeStaticReports(
          outputDir,
          inputName,
          source,
          executionError,
        );
      }
    }

    const artifacts: EnvLoggerArtifact[] = [];
    const warnings: string[] = fallback?.warnings ?? [];
    if (processWarning) {
      warnings.push(processWarning);
    }

    for (const outputName of reportNames) {
      const outputPath = join(outputDir, outputName);
      let outputBytes: Uint8Array;
      try {
        outputBytes = await readFile(outputPath);
      } catch {
        warnings.push(`${outputName} was not generated.`);
        continue;
      }

      if (outputBytes.byteLength > MAX_OUTPUT_BYTES) {
        warnings.push(`${outputName} exceeded the 8 MB attachment limit and was omitted.`);
        continue;
      }

      artifacts.push({
        outputPath,
        outputName,
        outputBytes: outputBytes.byteLength,
      });
    }

    const reportPath = join(outputDir, `${inputName}.envlog.json`);
    let summary = fallback?.summary ?? "EnvLogger completed.";
    try {
      const report = JSON.parse(await readFile(reportPath, "utf8")) as EnvLoggerReport;
      summary = formatSummary(report);
    } catch {
      warnings.push("The JSON summary could not be read.");
    }

    if (artifacts.length === 0) {
      throw new Error("EnvLogger completed without producing a report.");
    }

    return { artifacts, summary, warnings };
  } catch (error) {
    await rm(workingDir, { recursive: true, force: true });
    throw error;
  }
}

export async function cleanupEnvLogger(outputPath: string): Promise<void> {
  await rm(dirname(dirname(outputPath)), { recursive: true, force: true });
}