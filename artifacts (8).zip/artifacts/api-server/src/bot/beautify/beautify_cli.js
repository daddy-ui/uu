const fs = require("node:fs");

const [, , inputPath, outputPath] = process.argv;

if (!inputPath || !outputPath) {
  process.stderr.write("Usage: beautify_cli.js <input.lua> <output.lua>\n");
  process.exit(2);
}

if (!fs.existsSync(inputPath)) {
  process.stderr.write("The beautify input file does not exist.\n");
  process.exit(2);
}

const { parse } = require("./luaparse.js");
const beautify = require("./beautifier.js");

const source = fs.readFileSync(inputPath, "utf8");

let ast;
try {
  ast = parse(source);
} catch (err) {
  process.stderr.write(`Error: could not parse Lua source: ${err.message}\n`);
  process.exit(1);
}

let formatted;
try {
  formatted = beautify(ast);
} catch (err) {
  process.stderr.write(`Error: beautifier failed: ${err.message}\n`);
  process.exit(1);
}

fs.writeFileSync(outputPath, formatted, "utf8");
